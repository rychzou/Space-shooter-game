import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    int alienCounter = 0;
    Counter counter = new Counter();
    HealthBar healthbar = new HealthBar();
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 800, 1); 
        prepare();
    }
    public Counter getCounter()
    {
        return counter;
    }
    public HealthBar getHealthBar()
    {
        return healthbar;
    }
    public void act()
    {
        addAlien();
        addAsteroid();
        addHealthPack();
    }
    public void addAsteroid()
    {
        if (Greenfoot.getRandomNumber(120)<1)
        {
            addObject(new Asteroid(), Greenfoot.getRandomNumber(600),0);
        }
    }
    public void addAlien()
    {
        alienCounter++;
        if (alienCounter>59)
        {
            addObject(new Alien(), Greenfoot.getRandomNumber(600),0);
            alienCounter = 0;
        }
    }
    public void addHealthPack()
    {
        if (Greenfoot.getRandomNumber(150)<1)
        {
            addObject(new HealthPack(), Greenfoot.getRandomNumber(600), 0);
        }
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        addObject(healthbar, 250, 50);
        addObject(counter, 100, 50);
        SpaceShip spaceShip = new SpaceShip();
        addObject(spaceShip,314,699);
        spaceShip.setLocation(306,710);
    }
}
