import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SpaceShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceShip extends Actor
{
    boolean canFire = true;
    /**
     * Act - do whatever the SpaceShip wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        playerControl();
        fireBullet();
        if (isTouching(HealthPack.class))
        {
            World world = getWorld();
            MyWorld myWorld = (MyWorld)world;
            HealthBar healthbar = myWorld.getHealthBar();
            healthbar.gainHealth();
            removeTouching(HealthPack.class);
        }
    }
    public SpaceShip()
    {
        setRotation(270);
    }
    public void playerControl()
    {
        if (Greenfoot.isKeyDown("right"))
        {
            setLocation(getX()+3,getY());
        }
        if (Greenfoot.isKeyDown("left"))
        {
            setLocation(getX()-3,getY());
        }
        if (Greenfoot.isKeyDown("up"))
        {
            setLocation(getX(),getY()-3);
        }
        if (Greenfoot.isKeyDown("down"))
        {
            setLocation(getX(),getY()+3);
        }
    }
    public void fireBullet()
    {
        if (Greenfoot.isKeyDown("space") && canFire == true)
        {
            getWorld().addObject(new Bullet(), getX(),getY()-45);
            canFire = false;
        }
        else if (!Greenfoot.isKeyDown("space"))
        {
            canFire = true;
        }
    }
}
