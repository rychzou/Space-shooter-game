import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Asteroid here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Asteroid extends Enemies
{
    int timesShot = 2;
    /**
     * Act - do whatever the Asteroid wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY()+1);
        shotByBullet();
    }
    public void shotByBullet()
    {
        Actor bullet = getOneIntersectingObject(Bullet.class);
        if (bullet != null)
        {
            getWorld().removeObject(bullet);
            timesShot--;
        }
        if (timesShot == 0)
        {
            Counter counter = (Counter)getWorld().getObjects(Counter.class).get(0);
            getWorld().removeObject(this);
        }
        else if (isAtEdge() == true)
        {
            getWorld().removeObject(this);
        }
    }
    public void hitBySpaceShip()
    {
        if (isTouching(SpaceShip.class))
        {
            getWorld().removeObject(this);
        }
    }
}
