import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LoseGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LoseGame extends Actor
{
    /**
     * Act - do whatever the LoseGame wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        Greenfoot.playSound("Explosion.wav");
    }
}
